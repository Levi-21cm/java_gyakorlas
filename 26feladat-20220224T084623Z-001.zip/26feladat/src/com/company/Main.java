package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner konzol = new Scanner(System.in);
        System.out.println("Adj egy pozitiv egész szám");
        int szam = konzol.nextInt();
        int osszeg = 0;
        for (int i = 1; i <=szam;i++){
            if ((szam%i)==0){
                osszeg = osszeg + i; //csináltam egy összeg változót és mindig hozzá adtam az index értékét
            }
        }
        System.out.println(osszeg);
    }
}
