package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner konzol = new Scanner(System.in);
        System.out.println("Adj egy pozitiv egész szám");
        int szam = konzol.nextInt();

        for (int i = 1 ; i <= szam; i++){
            System.out.printf("\n"  + i);// a per n-el új sorba írom
        }
    }
}
